package com.esa.personaldocumenttool.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.rendering.PDFRenderer
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object PdfTools {
    fun imagesToPdf(context: Context, uris: List<Uri>, output: File) {
        require(uris.isNotEmpty()) { "Pilih minimal satu gambar." }
        val document = PdfDocument()
        try {
            uris.forEachIndexed { index, uri ->
                val bitmap = context.contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Gambar tidak dapat dibaca." }
                    BitmapFactory.decodeStream(input)
                } ?: error("Format gambar tidak didukung.")
                try {
                    val maxWidth = 1240
                    val maxHeight = 1754
                    val scale = minOf(1f, maxWidth.toFloat() / bitmap.width, maxHeight.toFloat() / bitmap.height)
                    val width = (bitmap.width * scale).toInt().coerceAtLeast(1)
                    val height = (bitmap.height * scale).toInt().coerceAtLeast(1)
                    val page = document.startPage(PdfDocument.PageInfo.Builder(width, height, index + 1).create())
                    page.canvas.drawBitmap(bitmap, null, Rect(0, 0, width, height), Paint(Paint.FILTER_BITMAP_FLAG))
                    document.finishPage(page)
                } finally { bitmap.recycle() }
            }
            output.outputStream().use { document.writeTo(it) }
        } finally { document.close() }
    }

    fun mergePdfs(context: Context, uris: List<Uri>, output: File) {
        require(uris.size >= 2) { "Pilih minimal dua file PDF untuk digabungkan." }
        PDFBoxResourceLoader.init(context)
        val merger = PDFMergerUtility()
        val tempFiles = mutableListOf<File>()
        try {
            uris.forEach { uri ->
                val temp = File.createTempFile("pdt_input_", ".pdf", context.cacheDir)
                context.contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Salah satu PDF tidak bisa dibaca." }
                    temp.outputStream().use { input.copyTo(it) }
                }
                tempFiles.add(temp)
                merger.addSource(temp)
            }
            merger.destinationFileName = output.absolutePath
            merger.mergeDocuments(null)
        } finally { tempFiles.forEach { it.delete() } }
    }

    fun splitPdfToZip(context: Context, uri: Uri, outputZip: File) {
        PDFBoxResourceLoader.init(context)
        val temp = File.createTempFile("pdt_split_", ".pdf", context.cacheDir)
        try {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "PDF tidak dapat dibaca." }
                temp.outputStream().use { input.copyTo(it) }
            }
            PDDocument.load(temp).use { source ->
                require(source.numberOfPages > 0) { "PDF tidak memiliki halaman." }
                ZipOutputStream(FileOutputStream(outputZip)).use { zip ->
                    for (i in 0 until source.numberOfPages) {
                        val pageDoc = PDDocument()
                        try {
                            pageDoc.importPage(source.getPage(i))
                            val entryName = "halaman_${i + 1}.pdf"
                            zip.putNextEntry(ZipEntry(entryName))
                            pageDoc.save(zip)
                            zip.closeEntry()
                        } finally { pageDoc.close() }
                    }
                }
            }
        } finally { temp.delete() }
    }

    fun pdfToImagesZip(context: Context, uri: Uri, outputZip: File) {
        PDFBoxResourceLoader.init(context)
        val temp = File.createTempFile("pdt_render_", ".pdf", context.cacheDir)
        try {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "PDF tidak dapat dibaca." }
                temp.outputStream().use { input.copyTo(it) }
            }
            PDDocument.load(temp).use { document ->
                val renderer = PDFRenderer(document)
                ZipOutputStream(FileOutputStream(outputZip)).use { zip ->
                    for (i in 0 until document.numberOfPages) {
                        val bitmap = renderer.renderImageWithDPI(i, 120f)
                        try {
                            zip.putNextEntry(ZipEntry("halaman_${i + 1}.png"))
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, zip)
                            zip.closeEntry()
                        } finally { bitmap.recycle() }
                    }
                }
            }
        } finally { temp.delete() }
    }
}
