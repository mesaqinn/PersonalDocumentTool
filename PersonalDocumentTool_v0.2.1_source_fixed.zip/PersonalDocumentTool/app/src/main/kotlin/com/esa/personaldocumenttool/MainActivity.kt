package com.esa.personaldocumenttool

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.SelectionContainer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.esa.personaldocumenttool.core.OcrTools
import com.esa.personaldocumenttool.core.PdfTools
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PersonalDocumentToolApp() }
    }
}

private enum class Task { IMAGES_PDF, MERGE, SPLIT, PDF_IMAGES, OCR }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonalDocumentToolApp() {
    val context = LocalContext.current
    var status by remember { mutableStateOf("Pilih alat untuk mulai mengolah dokumen.") }
    var busy by remember { mutableStateOf(false) }
    var ocrText by remember { mutableStateOf("") }
    var task by remember { mutableStateOf(Task.IMAGES_PDF) }
    var darkMode by remember { mutableStateOf(false) }

    fun runTask(uris: List<Uri>, selectedTask: Task) {
        if (uris.isEmpty()) return
        busy = true
        ocrText = ""
        status = "Sedang memproses file…"
        Thread {
            try {
                val stamp = System.currentTimeMillis()
                when (selectedTask) {
                    Task.IMAGES_PDF -> {
                        val out = File(context.cacheDir, "Dokumen_$stamp.pdf")
                        PdfTools.imagesToPdf(context, uris, out)
                        shareFile(context, out, "application/pdf")
                        android.os.Handler(context.mainLooper).post { status = "PDF berhasil dibuat dari ${uris.size} gambar." }
                    }
                    Task.MERGE -> {
                        val out = File(context.cacheDir, "PDF_Gabungan_$stamp.pdf")
                        PdfTools.mergePdfs(context, uris, out)
                        shareFile(context, out, "application/pdf")
                        android.os.Handler(context.mainLooper).post { status = "Berhasil menggabungkan ${uris.size} PDF." }
                    }
                    Task.SPLIT -> {
                        val out = File(context.cacheDir, "PDF_Terpisah_$stamp.zip")
                        PdfTools.splitPdfToZip(context, uris.first(), out)
                        shareFile(context, out, "application/zip")
                        android.os.Handler(context.mainLooper).post { status = "Setiap halaman disimpan sebagai PDF di dalam ZIP." }
                    }
                    Task.PDF_IMAGES -> {
                        val out = File(context.cacheDir, "Halaman_PDF_$stamp.zip")
                        PdfTools.pdfToImagesZip(context, uris.first(), out)
                        shareFile(context, out, "application/zip")
                        android.os.Handler(context.mainLooper).post { status = "Halaman PDF berhasil diekspor sebagai PNG di dalam ZIP." }
                    }
                    Task.OCR -> {
                        android.os.Handler(context.mainLooper).post {
                            OcrTools.recognizeImage(context, uris.first()) { result ->
                                ocrText = result
                                status = if (result.startsWith("OCR gagal:")) result else "OCR selesai. Teks bisa disalin dari kotak di bawah."
                                busy = false
                            }
                        }
                        return@Thread
                    }
                }
            } catch (e: Exception) {
                android.os.Handler(context.mainLooper).post { status = "Gagal memproses: ${e.message ?: "kesalahan tidak diketahui"}" }
            } finally {
                android.os.Handler(context.mainLooper).post { busy = false }
            }
        }.start()
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> runTask(uris, Task.IMAGES_PDF) }
    val mergePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> runTask(uris, Task.MERGE) }
    val singlePdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { runTask(listOf(it), task) } }
    val ocrPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { runTask(listOf(it), Task.OCR) } }

    MaterialTheme(colorScheme = if (darkMode) darkColorScheme() else lightColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("PDT", fontWeight = FontWeight.ExtraBold)
                            Text("PERSONAL DOCUMENT TOOL", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    actions = {
                        IconButton(onClick = { darkMode = !darkMode }) {
                            Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, contentDescription = "Ganti tema")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = true, onClick = {}, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Beranda") })
                    NavigationBarItem(selected = false, onClick = { status = "Pilih salah satu alat di beranda untuk mulai." }, icon = { Icon(Icons.Default.Build, null) }, label = { Text("Alat") })
                    NavigationBarItem(selected = false, onClick = { status = "Hasil terbaru dibagikan setelah pemrosesan. Simpan ke folder pilihan melalui menu berbagi." }, icon = { Icon(Icons.Default.FolderOpen, null) }, label = { Text("Dokumen") })
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
            ) {
                item {
                    Box(
                        Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF283593), Color(0xFF00897B))), RoundedCornerShape(24.dp)).padding(22.dp)
                    ) {
                        Column {
                            Text("Semua dokumen, lebih mudah.", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("Kelola PDF, gambar, dan teks langsung di perangkatmu.", color = Color.White)
                            Spacer(Modifier.height(16.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.OfflineBolt, null, tint = Color.White)
                                Spacer(Modifier.width(6.dp))
                                Text("Offline-first • Tanpa watermark otomatis", color = Color.White, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
                item { Text("Konversi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                item { ToolCard("Gambar ke PDF", "Gabungkan beberapa foto menjadi satu PDF", Icons.Default.Collections, !busy) { imagePicker.launch(arrayOf("image/*")) } }
                item { ToolCard("PDF ke gambar", "Ekspor setiap halaman menjadi PNG", Icons.Default.Image, !busy) { task = Task.PDF_IMAGES; singlePdfPicker.launch(arrayOf("application/pdf")) } }
                item { Text("Alat PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                item { ToolCard("Gabungkan PDF", "Pilih dua atau lebih file PDF", Icons.Default.MergeType, !busy) { mergePicker.launch(arrayOf("application/pdf")) } }
                item { ToolCard("Pisahkan PDF", "Simpan setiap halaman sebagai file PDF terpisah", Icons.Default.CallSplit, !busy) { task = Task.SPLIT; singlePdfPicker.launch(arrayOf("application/pdf")) } }
                item { Text("Pindai & teks", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                item { ToolCard("OCR gambar", "Kenali teks dari gambar di perangkat", Icons.Default.TextFields, !busy) { ocrPicker.launch(arrayOf("image/*")) } }
                if (busy) item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            LinearProgressIndicator(Modifier.fillMaxWidth())
                            Spacer(Modifier.height(8.dp))
                            Text("Sedang bekerja…")
                        }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Status proses", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text(status)
                            if (ocrText.isNotBlank()) {
                                Spacer(Modifier.height(12.dp))
                                SelectionContainer { Text(ocrText) }
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Teks OCR", ocrText))
                                    status = "Teks OCR disalin ke clipboard."
                                }) { Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(8.dp)); Text("Salin teks") }
                            }
                        }
                    }
                }
                item {
                    Text("Catatan: fitur yang tampil di aplikasi ini adalah fitur yang tersedia pada versi ini. Scanner kamera, kompresi PDF, tanda tangan, penguncian PDF, dan konversi Office masih perlu dikembangkan pada tahap berikutnya.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun ToolCard(title: String, subtitle: String, icon: ImageVector, enabled: Boolean, onClick: () -> Unit) {
    Card(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
                Box(Modifier.size(50.dp), contentAlignment = Alignment.Center) { Icon(icon, null, tint = MaterialTheme.colorScheme.onSecondaryContainer) }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(3.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, null)
        }
    }
}

private fun shareFile(context: Context, file: File, mime: String) {
    android.os.Handler(context.mainLooper).post {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Simpan atau bagikan hasil"))
    }
}
