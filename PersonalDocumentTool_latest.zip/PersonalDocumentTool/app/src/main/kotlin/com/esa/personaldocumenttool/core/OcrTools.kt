package com.esa.personaldocumenttool.core

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

object OcrTools {
    fun recognizeImage(
        context: Context,
        uri: Uri,
        callback: (String) -> Unit
    ) {
        try {
            val image = InputImage.fromFilePath(context, uri)
            val recognizer = TextRecognition.getClient(
                TextRecognizerOptions.DEFAULT_OPTIONS
            )
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    val text = result.text.ifBlank { "Tidak ada teks yang terdeteksi." }
                    callback(text)
                    recognizer.close()
                }
                .addOnFailureListener { error ->
                    callback("OCR gagal: ${error.message ?: "kesalahan tidak diketahui"}")
                    recognizer.close()
                }
        } catch (e: Exception) {
            callback("OCR gagal: ${e.message ?: "file tidak dapat dibaca"}")
        }
    }
}
