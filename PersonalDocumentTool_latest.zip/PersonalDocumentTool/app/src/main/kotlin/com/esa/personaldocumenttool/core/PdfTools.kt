package com.esa.personaldocumenttool.core

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfDocument
import android.net.Uri
import java.io.File

object PdfTools {
    /**
     * Converts multiple image URIs into a real PDF using Android's PdfDocument.
     * Images are decoded one at a time to keep memory usage reasonable.
     */
    fun imagesToPdf(context: Context, uris: List<Uri>, output: File) {
        require(uris.isNotEmpty()) { "Tidak ada gambar." }

        val document = PdfDocument()
        try {
            uris.forEachIndexed { index, uri ->
                val bitmap = context.contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "File tidak dapat dibaca." }
                    BitmapFactory.decodeStream(input)
                } ?: error("Gambar tidak dapat didekode.")

                try {
                    val maxWidth = 1654
                    val maxHeight = 2339
                    val scale = minOf(
                        1f,
                        maxWidth.toFloat() / bitmap.width,
                        maxHeight.toFloat() / bitmap.height
                    )
                    val width = (bitmap.width * scale).toInt()
                    val height = (bitmap.height * scale).toInt()

                    val page = document.startPage(
                        PdfDocument.PageInfo.Builder(width, height, index + 1).create()
                    )
                    page.canvas.drawBitmap(
                        bitmap,
                        null,
                        android.graphics.Rect(0, 0, width, height),
                        null
                    )
                    document.finishPage(page)
                } finally {
                    bitmap.recycle()
                }
            }
            output.outputStream().use { document.writeTo(it) }
        } finally {
            document.close()
        }
    }
}
