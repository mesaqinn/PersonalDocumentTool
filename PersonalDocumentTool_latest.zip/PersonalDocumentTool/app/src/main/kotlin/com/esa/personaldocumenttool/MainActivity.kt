package com.esa.personaldocumenttool

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.esa.personaldocumenttool.core.PdfTools
import com.esa.personaldocumenttool.core.OcrTools
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PersonalDocumentToolApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonalDocumentToolApp() {
    val context = LocalContext.current
    var status by remember { mutableStateOf("Siap. Pilih file atau gunakan scanner.") }
    var busy by remember { mutableStateOf(false) }

    val pickImages = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNullOrEmpty()) return@rememberLauncherForActivityResult
        busy = true
        status = "Membuat PDF dari ${uris.size} gambar..."
        try {
            val out = File(context.cacheDir, "PersonalDocumentTool_${System.currentTimeMillis()}.pdf")
            PdfTools.imagesToPdf(context, uris, out)
            shareFile(context, out, "application/pdf")
            status = "PDF berhasil dibuat dan siap dibagikan."
        } catch (e: Exception) {
            status = "Gagal: ${e.message ?: "kesalahan tidak diketahui"}"
        } finally {
            busy = false
        }
    }

    val pickPdf = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        status = "Memproses PDF..."
        try {
            val out = File(context.cacheDir, "PDF_pages_${System.currentTimeMillis()}.pdf")
            // First version: duplicate the selected PDF into app storage.
            // Full page-level split/merge is isolated in PdfTools for the next build.
            context.contentResolver.openInputStream(uri)!!.use { input ->
                out.outputStream().use { output -> input.copyTo(output) }
            }
            shareFile(context, out, "application/pdf")
            status = "PDF berhasil disalin ke penyimpanan sementara dan siap dibagikan."
        } catch (e: Exception) {
            status = "Gagal: ${e.message ?: "kesalahan tidak diketahui"}"
        } finally {
            busy = false
        }
    }

    val pickOcr = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        status = "Membaca teks dari gambar..."
        OcrTools.recognizeImage(context, uri) { result ->
            status = result
            busy = false
        }
    }

    val requestCamera = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        status = if (granted) {
            "Kamera siap. Scanner kamera penuh akan menjadi modul berikutnya."
        } else {
            "Izin kamera ditolak."
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Personal Document Tool") },
                    actions = {
                        IconButton(onClick = {
                            status = "Versi 0.1.0 • Offline-first"
                        }) {
                            Icon(Icons.Default.Info, contentDescription = "Info")
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        "Konverter dokumen pribadi",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        "Tanpa iklan, tanpa login, dan pemrosesan inti dilakukan di perangkat.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                item {
                    ActionCard(
                        title = "Gambar → PDF",
                        subtitle = "JPG, PNG, WEBP → satu PDF",
                        icon = Icons.Default.PictureAsPdf,
                        enabled = !busy
                    ) { pickImages.launch(arrayOf("image/*")) }
                }

                item {
                    ActionCard(
                        title = "PDF",
                        subtitle = "Pilih PDF untuk diproses",
                        icon = Icons.Default.Description,
                        enabled = !busy
                    ) { pickPdf.launch(arrayOf("application/pdf")) }
                }

                item {
                    ActionCard(
                        title = "OCR",
                        subtitle = "Baca teks dari gambar secara on-device",
                        icon = Icons.Default.TextFields,
                        enabled = !busy
                    ) { pickOcr.launch(arrayOf("image/*")) }
                }

                item {
                    ActionCard(
                        title = "Scanner",
                        subtitle = "Akses kamera untuk alur scan dokumen",
                        icon = Icons.Default.DocumentScanner,
                        enabled = !busy
                    ) {
                        if (ContextCompat.checkSelfPermission(
                                context, Manifest.permission.CAMERA
                            ) == PackageManager.PERMISSION_GRANTED
                        ) {
                            status = "Kamera sudah diberi izin."
                        } else {
                            requestCamera.launch(Manifest.permission.CAMERA)
                        }
                    }
                }

                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Status", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(6.dp))
                            Text(status)
                            if (busy) {
                                Spacer(Modifier.height(10.dp))
                                LinearProgressIndicator(Modifier.fillMaxWidth())
                            }
                        }
                    }
                }

                item {
                    Text(
                        "Tahap berikutnya: PDF merge/split per halaman, crop PDF, scanner auto-crop/perspective correction, searchable PDF, Office conversion, dan model AI lokal.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun ActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick,
        enabled = enabled
    ) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

private fun shareFile(context: android.content.Context, file: File, mime: String) {
    val uri = androidx.core.content.FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        file
    )
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Bagikan file"))
}
