# Personal Document Tool

Aplikasi Android pribadi, offline-first, untuk konversi dan pemrosesan dokumen.

## Status 0.1.0

Implementasi awal:

- Image (JPG/PNG/WEBP) → PDF
- Multi-image → satu PDF
- OCR gambar on-device menggunakan ML Kit
- File picker
- Share output
- Fondasi scanner kamera
- GitHub Actions untuk build APK

## Fitur yang direncanakan

- PDF → image
- Merge/split PDF per halaman
- Crop/rotate/compress PDF
- Auto document detection
- Perspective correction
- Searchable PDF
- DOCX ↔ PDF
- XLSX/PPTX → PDF
- Local AI/document understanding

## Build

Project membutuhkan JDK 17 dan Android SDK.

```bash
./gradlew :app:assembleDebug
```

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

Push ke branch `main`, atau jalankan workflow `Build Android APK` secara manual dari tab Actions.

## Catatan

Build pertama membutuhkan akses ke Google Maven/Maven Central untuk mengunduh dependency. Setelah dependency tersedia dalam cache, build dapat lebih cepat.

Jangan mengklaim fitur yang belum diimplementasikan sebagai selesai.
