# Personal Document Tool — versi pengembangan 0.2.0

Aplikasi Android Kotlin + Jetpack Compose, offline-first, tanpa watermark otomatis pada hasil ekspor.

## Fitur yang sudah diimplementasikan pada sumber ini
- Gambar banyak pilihan → satu PDF.
- Gabungkan beberapa PDF menjadi satu PDF menggunakan PDFBox-Android.
- Pisahkan PDF: setiap halaman menjadi PDF tersendiri dalam satu ZIP.
- PDF → PNG: setiap halaman diekspor sebagai PNG di dalam ZIP.
- OCR gambar dengan ML Kit on-device; hasil teks dapat dipilih dan disalin.
- Beranda Compose yang diperbarui, kartu alat, navigasi bawah, tema terang/gelap.
- Berbagi/menyimpan hasil lewat pemilih aplikasi Android.

## Belum tersedia pada versi ini
Scanner kamera dengan deteksi tepi/perspektif, kompresi PDF khusus, crop/rotate/hapus/urut halaman interaktif, tanda tangan, proteksi kata sandi, serta konversi DOCX/XLSX/PPTX. Antarmuka tidak mengklaim fitur tersebut sudah selesai.

## Build
JDK 17 dan Android SDK dibutuhkan. Jalankan `./gradlew :app:assembleDebug` jika Gradle wrapper tersedia. Build pertama memerlukan internet untuk mengunduh dependency.

## Catatan
- PDF yang dilindungi kata sandi mungkin gagal diproses oleh fungsi PDF pada versi ini.
- PDF besar dapat memakai banyak memori saat dirender menjadi PNG.
- OCR menggunakan model Latin ML Kit; dukungan hasil bergantung pada bahasa dan kualitas gambar.
